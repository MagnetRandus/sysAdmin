export interface __metadata {
	id: string;
	uri: string;
	etag: string;
	type: string;
}

export interface __deferred {
	uri: string;
}

export interface FirstUniqueAncestorSecurableObject {
	__deferred: __deferred;
}

export interface __deferred {
	uri: string;
}

export interface RoleAssignment {
	__deferred: __deferred;
}

export interface __deferred {
	uri: string;
}

export interface Author {
	__deferred: __deferred;
}

export interface __deferred {
	uri: string;
}

export interface ContentType {
	__deferred: __deferred;
}

export interface __deferred {
	uri: string;
}

export interface CreatablesInfo {
	__deferred: __deferred;
}

export interface __deferred {
	uri: string;
}

export interface DefaultView {
	__deferred: __deferred;
}

export interface __deferred {
	uri: string;
}

export interface DescriptionResource {
	__deferred: __deferred;
}

export interface __deferred {
	uri: string;
}

export interface EventReceiver {
	__deferred: __deferred;
}

export interface __deferred {
	uri: string;
}

export interface Field {
	__deferred: __deferred;
}

export interface __deferred {
	uri: string;
}

export interface Form {
	__deferred: __deferred;
}

export interface __deferred {
	uri: string;
}

export interface InformationRightsManagementSetting {
	__deferred: __deferred;
}

export interface __deferred {
	uri: string;
}

export interface Item {
	__deferred: __deferred;
}

export interface __deferred {
	uri: string;
}

export interface ParentWeb {
	__deferred: __deferred;
}

export interface __deferred {
	uri: string;
}

export interface RootFolder {
	__deferred: __deferred;
}

export interface __deferred {
	uri: string;
}

export interface Subscription {
	__deferred: __deferred;
}

export interface __deferred {
	uri: string;
}

export interface TitleResource {
	__deferred: __deferred;
}

export interface __deferred {
	uri: string;
}

export interface UserCustomAction {
	__deferred: __deferred;
}

export interface __deferred {
	uri: string;
}

export interface VersionPolicy {
	__deferred: __deferred;
}

export interface __deferred {
	uri: string;
}

export interface View {
	__deferred: __deferred;
}

export interface __deferred {
	uri: string;
}

export interface WorkflowAssociation {
	__deferred: __deferred;
}

export interface __metadata {
	type: string;
}

export interface CurrentChangeToken {
	__metadata: __metadata;
	stringValue: string;
}

export interface __metadata {
	type: string;
}

export interface ImagePath {
	__metadata: __metadata;
	decodedUrl: string;
}

export interface __metadata {
	type: string;
}

export interface ParentWebPath {
	__metadata: __metadata;
	decodedUrl: string;
}

export interface RootObject {
	__metadata: __metadata;
	firstUniqueAncestorSecurableObject: FirstUniqueAncestorSecurableObject;
	roleAssignments: RoleAssignment;
	author: Author;
	contentTypes: ContentType;
	creatablesInfo: CreatablesInfo;
	defaultView: DefaultView;
	descriptionResource: DescriptionResource;
	eventReceivers: EventReceiver;
	fields: Field;
	forms: Form;
	informationRightsManagementSettings: InformationRightsManagementSetting;
	items: Item;
	parentWeb: ParentWeb;
	rootFolder: RootFolder;
	subscriptions: Subscription;
	titleResource: TitleResource;
	userCustomActions: UserCustomAction;
	versionPolicies: VersionPolicy;
	views: View;
	workflowAssociations: WorkflowAssociation;
	AllowcontentTypes: boolean;
	baseTemplate: number;
	baseType: number;
	contentTypesEnabled: boolean;
	CrawlNonDefaultviews: boolean;
	created: string;
	currentChangeToken: CurrentChangeToken;
	defaultContentApprovalWorkflowid: string;
	defaultItemOpenUseListSetting: boolean;
	description: string;
	direction: string;
	disableCommenting: boolean;
	disableGridEditing: boolean;
	documentTemplateUrl?: any;
	draftVersionVisibility: number;
	enableAttachments: boolean;
	enableFolderCreation: boolean;
	enableMinorVersions: boolean;
	enableModeration: boolean;
	enableRequestSignOff: boolean;
	enableVersioning: boolean;
	entityTypeName: string;
	exemptFromBlockDownloadOfNonViewableFiles: boolean;
	fileSavePostProcessingEnabled: boolean;
	forceCheckout: boolean;
	hasExternalDataSource: boolean;
	hidden: boolean;
	id: string;
	imagePath: ImagePath;
	imageUrl: string;
	defaultSensitivityLabelForLibrary: string;
	sensitivityLabelToEncryptOnDownloadForLibrary?: any;
	irmEnabled: boolean;
	irmExpire: boolean;
	irmReject: boolean;
	isApplicationList: boolean;
	isCatalog: boolean;
	isPrivate: boolean;
	itemCount: number;
	lastItemDeletedDate: string;
	lastItemModifiedDate: string;
	lastItemUserModifiedDate: string;
	listExperienceOptions: number;
	listItemEntityTypeFullName: string;
	majorVersionLimit: number;
	majorWithMinorVersionsLimit: number;
	multipleDataList: boolean;
	noCrawl: boolean;
	parentWebPath: ParentWebPath;
	parentWebUrl: string;
	parserDisabled: boolean;
	serverTemplateCanCreateFolders: boolean;
	TemplateFeatureid: string;
	title: string;
}